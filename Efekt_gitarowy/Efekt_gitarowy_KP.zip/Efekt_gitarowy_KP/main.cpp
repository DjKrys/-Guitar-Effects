#include "Engine.h"

int main()
{
	Engine::getEngine().menu();
}